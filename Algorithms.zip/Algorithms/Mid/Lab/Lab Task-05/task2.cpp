
///Suppose, your mother asked to bring a tomatoes from Refrigerator.
/// How do you search it. Write a program to implement your technique.
#include <bits/stdc++.h>
using namespace std;


bool linearSearch(const char* refrigerator[], int size, const char* item_to_find) {
    for (int i = 0; i < size; i++) {
        if (strcmp(refrigerator[i], item_to_find) == 0) {
            return true;
        }
    }
    return false;
}

int main() {
    const char* refrigerator[] = {
        "apples", "milk", "eggs", "tomatoes", "cheese"
    };

    const char* item_to_find = "tomatoes";

    int size = sizeof(refrigerator) / sizeof(refrigerator[0]);

    if (linearSearch(refrigerator, size, item_to_find)) {
        cout << "Found " << item_to_find << " in the refrigerator!" << endl;
    } else {
        cout << "Did not find " << item_to_find << " in the refrigerator." << endl;
    }

    return 0;
}
