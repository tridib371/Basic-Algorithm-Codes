///Suppose your friend has started a 1-to-99 shop and he called you to help him.
///You found products of two packets are already
///sorted according to their prices and you are asked to sort
///those products into a shelf according to their prices.
/// Write a program to implement the technique.

#include <bits/stdc++.h>
using namespace std;



int main() {

    int packet1[] = {15, 55, 15, 8, 3, 5, 68, 4, 50, 17};

    int packet2[]= {21, 71, 6, 2, 7, 56, 27, 86, 82, 49};



    int totalProducts = 20;




    int own[20];
    for (int i = 0; i < 10; i++) {
        own[i] = packet1[i];
        own[i + 10] = packet2[i];
    }




    for (int i = 0; i < totalProducts - 1; i++) {
        for (int j = 0; j < totalProducts - i - 1; j++) {
            if (own[j] > own[j + 1]) {

                int temp = own[j];
                own[j] = own[j + 1];
                own[j + 1] = temp;
            }
        }
    }




    cout << "Sorted Products on the own: ";
    for (int i = 0; i < totalProducts; i++) {
        cout << own[i] << " ";
    }
    cout << endl;



    return 0;
}


