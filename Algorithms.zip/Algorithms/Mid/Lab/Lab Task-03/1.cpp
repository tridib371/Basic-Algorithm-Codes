# include <iostream>
using namespace std;

int Partition(int arr[], int a, int b)
{
 int pivot = arr[b];
 int pIndex = a;

 for(int i = a;i<b;i++)
 {
 if(arr[i]<pivot)
 {
 int temp = arr[i];
 arr[i] = arr[pIndex];
 arr[pIndex] = temp;
 pIndex++;
 }
 }

 int temp = arr[b];
 arr[b] = arr[pIndex];
 arr[pIndex] = temp;

 return pIndex;
}

void QuickSort(int arr[], int a, int b)
{
 if(a<b)
 {
 int p = Partition(arr,a, b);
 QuickSort(arr, a, (p-1));
 QuickSort(arr, (p+1), b);
 }
}

int main()
{

 int size=0;
 cout<<"Enter size of array: ";
 cin>>size;
 int myarray[size];

 cout<<"Enter the elements: "<<endl;
 for(int i=0;i<size;i++)
 {
 cin>>myarray[i];
 }
 cout<<"Before Sorting"<<endl;
 for(int i=0;i<size;i++)
 {
 cout<<myarray[i]<<" ";
 }
 cout<<endl;

 QuickSort(myarray,0,(size-1));

 cout<<"After Sorting"<<endl;
 for(int i=0;i<size;i++)
 {
 cout<<myarray[i]<<" ";
 }

 return 0;
}
