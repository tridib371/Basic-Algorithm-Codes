#include <iostream>
using namespace std;
void insertItemAtMiddle(int arr[], int& n, int newItem)
{
  if (n == 0)
  {
    arr[0] = newItem;
    n++;
  }
  else
  {
    int mid = n / 2;
    for (int i = n; i > mid; i--)
    {
      arr[i] = arr[i - 1];
    }
    arr[mid] = newItem;
    n++;
  }
}

int main()
{
  int arr[100];
  int n;
  cout << "Enter the number of elements in the array: ";
  cin >> n;
  cout << "Enter the elements of the array:\n";
  for (int i = 0; i < n; i++)
  {
    cout << "Element " << i + 1 << ": ";
    cin >> arr[i];
  }

  int newItem;
  cout << "Enter the new item to insert: ";
  cin >> newItem;
  cout << "Original array: ";
  for (int i = 0; i < n; i++)
  {
    cout << arr[i] << " ";
  }
  cout << endl;
  insertItemAtMiddle(arr, n, newItem);
  cout << "Array after inserting at the middle: ";
  for (int i = 0; i < n; i++)
  {
    cout << arr[i] << " ";
  }
  cout << endl;

  return 0;
}
