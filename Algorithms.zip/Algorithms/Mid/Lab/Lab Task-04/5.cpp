#include <iostream>
using namespace std;
const int MAX_SIZE = 100;
int main()
{
  int matrix[MAX_SIZE][MAX_SIZE];
  int rows, cols;

  cout << "Enter the number of rows: ";
  cin >> rows;
  cout << "Enter the number of columns: ";
  cin >> cols;
  cout << "Enter the elements of the matrix:\n";
  for (int i = 0; i < rows; i++)
  {
    for (int j = 0; j < cols; j++)
    {
      cout << "Enter element at position (" << i + 1 << ", " << j + 1 << "): ";
      cin >> matrix[i][j];
    }
  }

  int diagonalSum = 0;
  int minDim = (rows < cols) ? rows : cols;
  for (int i = 0; i < minDim; i++)
  {
    diagonalSum += matrix[i][i];
  }

  cout << "Matrix:\n";
  for (int i = 0; i < rows; i++)
  {
    for (int j = 0; j < cols; j++)
    {
      cout << matrix[i][j] << " ";
    }
    cout << endl;
  }

  cout << "Sum of the main diagonal elements: " << diagonalSum << endl;

  return 0;
}
