#include <iostream>
using namespace std;
const int MAX_SIZE = 100;
void bubbleSort(int arr[], int n)
{
  for (int i = 0; i < n - 1; i++)
{
    for (int j = 0; j < n - i - 1; j++)
    {
      if (arr[j] > arr[j + 1])
      {
        int temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
}

void countingSort(int arr[], int n)
{
  int max = arr[0];
  for (int i = 1; i < n; i++)
  {
    if (arr[i] > max)
    {
      max = arr[i];
    }
  }

  int count[max + 1] = {0};

  for (int i = 0; i < n; i++)
  {
    count[arr[i]]++;
  }

  int index = 0;
  for (int i = 0; i <= max; i++)
  {
    while (count[i] > 0)
    {
      arr[index++] = i;
      count[i]--;
    }
  }
}

int linearSearch(int arr[], int n, int target)
{
  for (int i = 0; i < n; i++)
  {
    if (arr[i] == target)
    {
      return i;
    }
  }
  return -1;
}

int main()
{
  int n;

  cout << "Enter the number of elements: ";
  cin >> n;

  int arr[n];
  cout << "Enter the elements of the array:\n";
  for (int i = 0; i < n; i++)
  {
    cout << "Element " << i + 1 << ": ";
    cin >> arr[i];
  }

  cout << "Original array: ";
  for (int i = 0; i < n; i++)
  {
    cout << arr[i] << " ";
  }
  cout << endl;

  bubbleSort(arr, n);

  cout << "Array after Bubble Sort: ";
  for (int i = 0; i < n; i++)
  {
    cout << arr[i] << " ";
  }
  cout << endl;

  int target;
  cout << "Enter the element to search: ";
  cin >> target;

  int searchResult = linearSearch(arr, n, target);

  if (searchResult != -1)
  {
    cout << "Linear search: Element " << target << " found at index " << searchResult << endl;
  }
    else
  {
    cout << "Linear search: Element " << target << " not found" << endl;
  }

  int arr2[n];
  for (int i = 0; i < n; i++)
  {
    arr2[i] = arr[i];
  }
  countingSort(arr2, n);

  cout << "Array after Counting Sort: ";
  for (int i = 0; i < n; i++)
  {
    cout << arr2[i] << " ";
  }
  cout << endl;

  return 0;
}
