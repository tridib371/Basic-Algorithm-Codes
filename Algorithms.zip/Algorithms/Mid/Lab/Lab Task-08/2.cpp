#include <iostream>
#include <algorithm>
using namespace std;

struct Item
{
    int weight, price;
};

bool cmp(Item a, Item b)
{
    double r1 = (double)a.price / a.weight;
    double r2 = (double)b.price / b.weight;
    return r1 > r2;
}

double fractionalKnapsack(int W, Item arr[], int n)
{
    sort(arr, arr + n, cmp);
    double res = 0.0;
    for (int i = 0; i < n; i++)

    {
        if (arr[i].weight <= W)
        {
            res += arr[i].price;
            W -= arr[i].weight;
        } else {
            res += arr[i].price * ((double)W / arr[i].weight);
            break;
        }
    }
    return res;
}

int main()
{
    int W = 10;
    Item arr[] = {{3, 470}, {2, 230}, {3, 360}, {5, 500}};
    int n = sizeof(arr) / sizeof(arr[0]);
    double max_price = fractionalKnapsack(W, arr, n);
    cout << "Maximum value that can be obtained: " << max_price << endl;

    int notes[] = {1000, 500, 200, 100, 50, 20, 10, 5, 2, 1};
    int prices[] = {470, 230, 360, 500};
    int weights[] = {3, 2, 3, 5};
    n = sizeof(notes) / sizeof(notes[0]);
    int m = sizeof(prices) / sizeof(prices[0]);
    int min_notes[m];
    for (int i = 0; i < m; i++)
    {
        min_notes[i] = prices[i] / notes[0];
        for (int j = 1; j < n; j++)
        {
            if (prices[i] >= notes[j])
            {
                min_notes[i] += prices[i] / notes[j];
                prices[i] %= notes[j];
            }
        }
    }
    int total_notes = 0;
    for (int i = 0; i < m; i++)
    {
        total_notes += min_notes[i];
    }
    cout << "Minimum number of notes required: " << total_notes << endl;

    return 0;
}
