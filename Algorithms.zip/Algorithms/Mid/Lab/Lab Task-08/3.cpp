#include <iostream>
#include <string>
using namespace std;

struct Customer
{
    string name;
    string NID;
    int age;
    string occupation;
    double accountBalance;
};

int main()
{
    Customer customers[10];

     for (int i = 0; i < 10; i++)
    {
        cout << "Customer " << (i + 1) << " details:" << endl;

        cout << "Name: ";
        cin >> customers[i].name;

        cout << "NID: ";
        cin >> customers[i].NID;

        cout << "Age: ";
        cin >> customers[i].age;

        cout << "Occupation: ";
        cin >> customers[i].occupation;

        cout << "Account Balance: $";
        cin >> customers[i].accountBalance;
    }

    for (int i = 0; i < 10; i++)
    {
        for (int year = 1; year <= 10; year++)
        {
            customers[i].accountBalance *= 1.065;
        }
    }


    cout << "Customer Information and Account Balances after 10 years:" << endl;
    for (int i = 0; i < 10; i++)
    {
        cout << "Customer " << (i + 1) << " - Name: " << customers[i].name << ", NID: " << customers[i].NID
             << ", Age: " << customers[i].age << ", Occupation: " << customers[i].occupation
             << ", Annual Balance: $" << customers[i].accountBalance << endl;
    }

    return 0;
}
