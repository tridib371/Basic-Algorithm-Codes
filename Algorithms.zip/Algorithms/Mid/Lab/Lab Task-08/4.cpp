#include <iostream>
#include <string>
using namespace std;

struct Student
{
    string S_name;
    string S_ID;
    int S_age;
    string S_Department;
    double SGPA;
};

int main()
{
    Student students[10];

    for (int i = 0; i < 10; i++)
    {
        cout << "Student " << (i + 1) << " details:" << endl;

        cout << "Name: ";
        cin >> students[i].S_name;

        cout << "ID: ";
        cin >> students[i].S_ID;

        cout << "Age: ";
        cin >> students[i].S_age;

        cout << "Department: ";
        cin >> students[i].S_Department;

        cout << "Enter SGPA (out of 4.0) for Student " << (i + 1) << ": ";
        cin >> students[i].SGPA;
    }

    double totalCGPA = 0.0;
    for (int i = 0; i < 10; i++)
    {
        totalCGPA += students[i].SGPA;
    }
    double CGPA = totalCGPA / 10.0;

    for (int i = 0; i < 10; i++)
    {
        if (students[i].SGPA >= 3.75)
        {
            cout << "Student " << students[i].S_name << " is eligible for a 25% waiver." << endl;
        }
          else
        {
            cout << "Student " << students[i].S_name << " is not eligible for a 25% waiver." << endl;
        }
    }


    cout << "Student Information and CGPA:" << endl;
    for (int i = 0; i < 10; i++)
    {
        cout << "Student " << (i + 1) << " - Name: " << students[i].S_name << ", ID: " << students[i].S_ID
             << ", Age: " << students[i].S_age << ", Department: " << students[i].S_Department
             << ", SGPA: " << students[i].SGPA << endl;
    }

    cout << "Total CGPA of all students: " << CGPA << endl;

    return 0;
}
