#include <iostream>
using namespace std;


int linearSearch(int arr[], int n, int x)
{
  for (int i = 0; i < n; i++)
  {
    if (arr[i] == x)
    {
      return i;
    }
  }
  return -1;
}


void displayArray(int arr[], int n)
{
  for (int i = 0; i < n; i++)
  {
    cout << arr[i] << " ";
  }
  cout << endl;
}

int main()
{
  int arr[] = {9,5,1,0,2,7,6,3,8,19};
  int n = sizeof(arr) / sizeof(arr[0]);

  int choice;
  cout << "Enter your choice:" << endl;
  cout << "1. Linear search" << endl;
  cout << "2. Binary search" << endl;
  cin >> choice;

  if (choice == 1)
  {
    int x;
    cout << "Enter the element to search: ";
    cin >> x;

    int index = linearSearch(arr, n, x);
    if (index != -1)
    {
      cout << "The element " << x << " is found at index " << index << endl;
    }
    else
    {
      cout << "The element " << x << " is not found in the array" << endl;
    }
  }

  else if (choice == 2)
  {

    int x;
    cout << "Enter the element to search: ";
    cin >> x;


     int index = linearSearch(arr, n, x);
    if (index != -1)
    {
      cout << "The element " << x << " is found at index " << index << endl;
    }
    else
    {
      cout << "The element " << x << " is not found in the array" << endl;
    }
  }

  else
  {
    cout << "Invalid choice!" << endl;
  }

  return 0;
}
