#include<iostream>
using namespace std;
int main()
{
    int arr[50], a, i, j, k, e, index;
    cout<<"Enter the Size for Array: ";
    cin>>a;
    cout<<"Enter "<<a<<" Array Elements: ";
    for(i=0; i<a; i++)
        cin>>arr[i];
    for(i=1; i<a; i++)
    {
        e = arr[i];
        if(e<arr[i-1])
        {
            for(j=0; j<=i; j++)
            {
                if(e<arr[j])
                {
                    index = j;
                    for(k=i; k>j; k--)
                        arr[k] = arr[k-1];
                    break;
                }
            }
        }
        else
            continue;
        arr[index] = e;
    }
    cout<<"\nThe Sorted Array:\n";
    for(i=0; i<a; i++)
        cout<<arr[i]<<"  ";
    cout<<endl;
    return 0;
}
