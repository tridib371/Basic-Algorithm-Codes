#include <iostream>
using namespace std;

int main()
{
    int notes[] = {1000, 500, 200, 100, 50, 20, 10, 5, 2};
    int n = sizeof(notes) / sizeof(notes[0]);
    int amount = 2887;
    int count[n] = {0};

    for (int i = 0; i < n; i++)
    {
        while (amount >= notes[i])
        {
            amount -= notes[i];
            count[i]++;
        }
    }

    cout << "The minimum number of notes required to pay " << "2887 taka is: " << endl;
    for (int i = 0; i < n; i++)
    {
        if (count[i] > 0)
        {
            cout << count[i] << " notes of " << notes[i] << " taka" << endl;
        }
    }
    return 0;
}
