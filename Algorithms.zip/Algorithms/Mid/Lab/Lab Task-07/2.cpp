#include <iostream>
#include <algorithm>
using namespace std;

struct Item
{
    int weight, price;
};

bool cmp(struct Item a, struct Item b)
{
    double r1 = (double)a.price / (double)a.weight;
    double r2 = (double)b.price / (double)b.weight;
    return r1 > r2;
}

double fractionalKnapsack(int W, struct Item arr[], int n)
{
    sort(arr, arr + n, cmp);
    double profit = 0.0;

    for (int i = 0; i < n; i++)
    {
        if (W == 0)
        {
            return profit;
        }
        else if (arr[i].weight <= W)
        {
            W -= arr[i].weight;
            profit += arr[i].price;
        }
        else
        {
            double fraction = (double)W / (double)arr[i].weight;
            profit += arr[i].price * fraction;
            W = 0;
        }
    }
    return profit;
}

int main()
{
    int n = 5, W = 15;
    struct Item arr[n] = {{7, 700}, {5, 600}, {2, 240}, {5, 250}, {3, 1050}};

    cout << "Maximum profit earned: " << fractionalKnapsack(W, arr, n) << " taka" << endl;

    return 0;
}
