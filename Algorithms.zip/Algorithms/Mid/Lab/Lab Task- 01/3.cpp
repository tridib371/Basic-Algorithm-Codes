#include<iostream>
using namespace std;

int main()
{
        int mark[8], i;
        float sum=0,avg;

        cout<<"\nEnter Marks in 8 subjects  \n";
        for(i=0; i<8; i++)
        {
            cout<<"\nEnter Marks[ "<<i+1<<" ] :  ";
                cin>>mark[i];
                sum=sum+mark[i];
        }

        avg=sum/8;

        cout<<"\nYour Grade is : ";
        if(avg>80)
        {
                cout<<"[ A ]\n";
        }
        else if(avg>60 && avg<=80)
        {
                cout<<"[ B ]\n";
        }
        else if(avg>40 && avg<=60)
        {
                cout<<"[ C ]\n";
        }
        else
        {
                cout<<"[ D ]\n";
        }

        return 0;
}
