#include <iostream>
using namespace std;
int main()
{
   int i,a=1,num;
  cout<<"Enter any Number: ";
 cin>>num;
  for(i=1;i<=num;i++)
  {
      a=a*i;
  }
  cout<<"Factorial of the number is: "<<a<<endl;
  return 0;
}
