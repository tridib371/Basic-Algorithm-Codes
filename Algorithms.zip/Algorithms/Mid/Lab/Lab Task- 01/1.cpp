#include <iostream>
using namespace std;

int main()
{
    int height, base;
    float a;
    cout<<"Enter the height : ";
    cin>>height;
    cout<<"Enter the base : ";
    cin>>base;
    a= (0.5)*height*base;

    cout<<"The Area of triangle is : "<<a;
	return 0;
}
