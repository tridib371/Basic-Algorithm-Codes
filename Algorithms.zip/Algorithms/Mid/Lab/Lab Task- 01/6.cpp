#include<iostream>
using namespace std;
int main()
{

  double number;

  cout << "Enter a Number : ";
  cin >> number;


  if (number > 0)
    cout << "It's a Positive Number." << endl;
  else if(number < 0)
    cout << "It's a Negative Number." << endl;
  else
    cout << "It's Zero." << endl;

  return 0;
}
