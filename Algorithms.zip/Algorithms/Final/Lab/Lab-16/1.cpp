#include <iostream>
using namespace std;
int mcm(int dimensions[], int n)
{
    int dp[n][n];
    for (int i = 1; i < n; i++)
    {
        dp[i][i] = 0;
    }

    for (int l = 2; l < n; l++)
    {
        for (int i = 1; i < n - l + 1; i++)
        {
            int j = i + l - 1;
            dp[i][j] = INT_MAX;

            for (int k = i; k < j; k++)
            {
                int cost = dp[i][k] + dp[k + 1][j] + dimensions[i - 1] * dimensions[k] * dimensions[j];
                dp[i][j] = min(dp[i][j], cost);
            }
        }
    }

    return dp[1][n - 1];
}

int main()
{
    int dimensions[] = {10, 20, 30, 40, 50};
    int n = sizeof(dimensions) / sizeof(dimensions[0]);
    int minMultiplications = mcm(dimensions, n);

    cout << "Minimum number of multiplications: " << minMultiplications << endl;

    return 0;
}
