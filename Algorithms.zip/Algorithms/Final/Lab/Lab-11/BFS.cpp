#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Graph
{
    int numVertices;
    vector<vector<int>> adjLists;

public:
    Graph(int V)
    {
        numVertices = V;
        adjLists.resize(V);
    }

    void addEdge(int src, int dest)
    {
        adjLists[src].push_back(dest);
    }

    bool BFS(int start, int dest)
    {
        vector<bool> visited(numVertices, false);
        queue<int> q;

        visited[start] = true;
        q.push(start);

        while (!q.empty())
        {
            int current = q.front();
            q.pop();

            if (current == dest)
                return true;

            for (int neighbor : adjLists[current])
            {
                if (!visited[neighbor])
                {
                    visited[neighbor] = true;
                    q.push(neighbor);
                }
            }
        }

        return false;
    }
};

int main()
{
    int V = 5;
    Graph graph(V);

    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    graph.addEdge(2, 3);

    int startNode = 1;
    int destNode = 3;

    if (graph.BFS(startNode, destNode))
        cout << "Path exists from " << startNode << " to " << destNode << endl;
    else
        cout << "No path exists from " << startNode << " to " << destNode << endl;

    return 0;
}
