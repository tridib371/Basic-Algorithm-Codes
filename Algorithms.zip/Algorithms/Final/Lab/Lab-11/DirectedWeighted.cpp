#include <iostream>
#include <vector>
using namespace std;

class Graph
{
private:
    int vertices;
    vector<vector<pair<int, int>>> adjList;

public:
    Graph(int V) : vertices(V), adjList(V) {}

    void addEdge(int u, int v, int weight)
    {
        adjList[u].push_back({v, weight});
    }

    void printGraph()
    {
        for (int i = 0; i < vertices; ++i)
        {
            cout << "Adjacency list of vertex " << i << ": ";
            for (auto p : adjList[i])
            {
                cout << "(" << p.first << ", " << p.second << ") ";
            }
            cout << endl;
        }
    }
};

int main()
{
    int V = 4;
    Graph g(V);

    g.addEdge(0, 1, 5);
    g.addEdge(0, 2, 3);
    g.addEdge(1, 2, 2);
    g.addEdge(2, 3, 7);

    g.printGraph();

    return 0;
}
