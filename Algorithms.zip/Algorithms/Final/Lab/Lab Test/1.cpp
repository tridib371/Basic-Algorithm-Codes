#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Item
{
    int weight;
    int profit;
    double ratio;
};

bool compare(Item i1, Item i2)
{
    return i1.ratio > i2.ratio;
}

double fractionalKnapsack(int capacity, vector<Item>& items)
{
    sort(items.begin(), items.end(), compare);

    double totalProfit = 0.0;

    for (const auto& item : items)
    {
        if (capacity >= item.weight)
        {
            totalProfit += item.profit;
            capacity -= item.weight;
        }
          else
        {
            totalProfit += (static_cast<double>(capacity) / item.weight) * item.profit;
            break;
        }
    }

    return totalProfit;
}

int main()
{
    int n;
    cout << "Enter the number of items: ";
    cin >> n;

    vector<Item> items;
    items.reserve(n);

    cout << "Enter the weight and profit for each item:\n";
    for (int i = 0; i < n; ++i)
    {
        int weight, profit;
        cout << "Item " << i + 1 << ": ";
        cin >> weight >> profit;
        items.push_back({weight, profit, 0.0});
    }

    int capacity;
    cout << "Enter the knapsack capacity: ";
    cin >> capacity;

    for (auto& item : items)
    {
        item.ratio = static_cast<double>(item.profit) / item.weight;
    }

    double maxProfit = fractionalKnapsack(capacity, items);

    cout << "Maximum Profit: " << maxProfit << endl;

    return 0;
}
