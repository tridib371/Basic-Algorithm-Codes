#include <iostream>
using namespace std;
int knapsack(int W, int wt[], int val[], int n)
{
  int K[n + 1][W + 1];
  for (int i = 0; i <= n; i++)
  {
    K[i][0] = 0;
  }

  for (int j = 0; j <= W; j++)
  {
    K[0][j] = 0;
  }

  for (int i = 1; i <= n; i++)
  {
    for (int j = 1; j <= W; j++)
    {
      if (wt[i - 1] <= j)
      {
        K[i][j] = max(val[i - 1] + K[i - 1][j - wt[i - 1]], K[i - 1][j]);
      }
        else
      {
        K[i][j] = K[i - 1][j];
      }
    }
  }

  return K[n][W];
}

int main()
{
  int wt[] = {3, 1, 2, 4, 5, 6};
  int val[] = {2, 4, 5, 5, 7, 8};
  int W = 15;
  int n = sizeof(wt) / sizeof(wt[0]);
  int maxValue = knapsack(W, wt, val, n);
  cout << "Maximum taste value: " << maxValue << endl;

  return 0;
}
