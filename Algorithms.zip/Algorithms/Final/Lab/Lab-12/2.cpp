#include <iostream>
using namespace std;

const int MAX_VERTICES = 6;

class Graph {
    int V;
    int adj[MAX_VERTICES][MAX_VERTICES];

public:
    Graph(int V) {
        this->V = V;
        for (int i = 0; i < V; ++i)
            for (int j = 0; j < V; ++j)
                adj[i][j] = 0;
    }

    void addEdge(int v, int w) {
        adj[v][w] = 1;
    }

    void topologicalSortUtil(int v, bool visited[], int Stack[], int& top) {
        visited[v] = true;
        for (int u = 0; u < V; ++u) {
            if (adj[v][u] && !visited[u])
                topologicalSortUtil(u, visited, Stack, top);
        }
        Stack[++top] = v;
    }

    void topologicalSort() {
        bool visited[MAX_VERTICES] = {false};
        int Stack[MAX_VERTICES];
        int top = -1;

        for (int i = 0; i < V; ++i) {
            if (!visited[i])
                topologicalSortUtil(i, visited, Stack, top);
        }

        cout << "Topological Sort Order: ";
        while (top >= 0) {
            cout << char('A' + Stack[top--]) << " ";
        }
    }
};

int main() {
    Graph g(6);
    g.addEdge(S, A);
    g.addEdge(S, B);
    g.addEdge(A, B);
    g.addEdge(A, C);
    g.addEdge(B, D);
    g.addEdge(C, E);
    g.addEdge(E, C);
    g.addEdge(A, D);

    cout << "Following is a Topological Sort of the given graph: ";
    g.topologicalSort();

    return 0;
}
