#include <iostream>
using namespace std;

const int MAX_VERTICES = 6;

class Graph {
    int V;
    int adj[MAX_VERTICES][MAX_VERTICES];

public:
    Graph(int V) {
        this->V = V;
        for (int i = 0; i < V; ++i)
            for (int j = 0; j < V; ++j)
                adj[i][j] = 0;
    }

    void addEdge(int v, int w) {
        adj[v][w] = 1;
    }

    void DFSUtil(int v, bool visited[]) {
        visited[v] = true;
        cout << char('A' + v) << " ";

        for (int u = 0; u < V; ++u) {
            if (adj[v][u] && !visited[u])
                DFSUtil(u, visited);
        }
    }

    void printSCCs() {
        bool visited[MAX_VERTICES] = {false};

        for (int i = 0; i < V; ++i) {
            if (!visited[i]) {
                cout << "Strongly Connected Component: ";
                DFSUtil(i, visited);
                cout << endl;
            }
        }
    }
};

int main() {
    Graph g(6);
    g.addEdge(S, A);
    g.addEdge(S, B);
    g.addEdge(A, B);
    g.addEdge(A, C);
    g.addEdge(B, D);
    g.addEdge(C, E);
    g.addEdge(E, C);
    g.addEdge(A, D);

    cout << "Strongly Connected Components in the given graph:\n";
    g.printSCCs();

    return 0;
}
