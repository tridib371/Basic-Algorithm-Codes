#include <iostream>
#include <vector>
#include <stack>
using namespace std;

const int MAX_VERTICES = 6;

class Graph {
    int V;
    int adj[MAX_VERTICES][MAX_VERTICES];

public:
    Graph(int V) {
        this->V = V;
        for (int i = 0; i < V; ++i)
            for (int j = 0; j < V; ++j)
                adj[i][j] = 0;
    }

    void addEdge(int v, int w) {
        adj[v][w] = 1;
    }

    bool DFS(int start_node, int target_node, vector<int>& path) {
        stack<int> route;
        vector<bool> visited(V, false);

        route.push(start_node);
        visited[start_node] = true;

        while (!route.empty()) {
            int current_node = route.top();
            route.pop();

            if (current_node == target_node) {
                path.push_back(current_node);
                return true;
            }

            for (int u = 0; u < V; ++u) {
                if (adj[current_node][u] && !visited[u]) {
                    route.push(u);
                    visited[u] = true;
                }
            }
        }

        return false;
    }
};

int main() {
    Graph g(6);
    g.addEdge(S, A);
    g.addEdge(S, B);
    g.addEdge(A, B);
    g.addEdge(A, C);
    g.addEdge(B, D);
    g.addEdge(C, E);
    g.addEdge(E, C);
    g.addEdge(A, D);

    int start_node = A;
    int target_node = C;

    vector<int> path;
    if (g.DFS(start_node, target_node, path)) {
        cout << "Path from Node" << start_node << " to Node" << target_node << ": ";
        for (int node : path)
            cout << char('A' + node) << " ";
        cout << endl;
    } else {
        cout << "No path from Node" << start_node << " to Node" << target_node << endl;
    }

    return 0;
}
