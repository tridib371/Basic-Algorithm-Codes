#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int INF = INT_MAX;

typedef pair<int, int> pii;

class Graph
{
public:
    int V;
    vector<vector<pii>> adj;

    Graph(int vertices) : V(vertices), adj(vertices) {}

    void addEdge(int u, int v, int weight)
    {
        adj[u].emplace_back(v, weight);
        adj[v].emplace_back(u, weight);
    }

    void dijkstra(int source, vector<int>& distance)
    {
        priority_queue<pii, vector<pii>, greater<pii>> pq;
        pq.push({0, source});
        distance[source] = 0;

        while (!pq.empty())
        {
            int u = pq.top().second;
            pq.pop();

            for (const auto& neighbor : adj[u])
            {
                int v = neighbor.first;
                int w = neighbor.second;

                if (distance[v] > distance[u] + w)
                {
                    distance[v] = distance[u] + w;
                    pq.push({distance[v], v});
                }
            }
        }
    }
};

int main()
{
    int vertices, edges;
    cout << "Enter the number of vertices and edges: ";
    cin >> vertices >> edges;

    Graph graph(vertices);

    cout << "Enter the edges (u v weight):" << endl;
    for (int i = 0; i < edges; ++i)
    {
        int u, v, weight;
        cin >> u >> v >> weight;
        graph.addEdge(u, v, weight);
    }

    int source, destination;
    cout << "Enter the source and destination nodes: ";
    cin >> source >> destination;

    vector<int> distance(vertices, INF);
    graph.dijkstra(source, distance);

    if (distance[destination] == INF)
    {
        cout << "There is no path from source to destination." << endl;
    }
     else
    {
        cout << "Shortest distance from " << source << " to " << destination << ": " << distance[destination] << endl;
    }

    return 0;
}
