#include <iostream>
#include <vector>
#include <climits>

using namespace std;

const int INF = INT_MAX;

struct Edge
{
    int source, destination, weight;
};

class Graph
{
public:
    int V, E;
    vector<Edge> edges;

    Graph(int vertices, int edgesCount) : V(vertices), E(edgesCount) {}

    void addEdge(int u, int v, int w)
    {
        edges.push_back({u, v, w});
    }

    void bellmanFord(int source, vector<int>& distance)
    {
        distance[source] = 0;

        for (int i = 0; i < V - 1; ++i)
        {
            for (const auto& edge : edges)
            {
                int u = edge.source;
                int v = edge.destination;
                int w = edge.weight;

                if (distance[u] != INF && distance[u] + w < distance[v])
                {
                    distance[v] = distance[u] + w;
                }
            }
        }
    }
};

int main()
{
    int vertices, edges;
    cout << "Enter the number of vertices and edges: ";
    cin >> vertices >> edges;

    Graph graph(vertices, edges);

    cout << "Enter the edges (u v weight):" << endl;
    for (int i = 0; i < edges; ++i)
    {
        int u, v, weight;
        cin >> u >> v >> weight;
        graph.addEdge(u, v, weight);
    }

    int source, destination;
    cout << "Enter the source and destination nodes: ";
    cin >> source >> destination;

    vector<int> distance(vertices, INF);
    graph.bellmanFord(source, distance);

    if (distance[destination] == INF)
    {
        cout << "There is no path from source to destination." << endl;
    }
     else
    {
        cout << "Shortest distance from " << source << " to " << destination << ": " << distance[destination] << endl;
    }

    return 0;
}
