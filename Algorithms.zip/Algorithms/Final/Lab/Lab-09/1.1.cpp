#include <iostream>
using namespace std;

struct Grocery
{
    int weight;
    int cost;
};

int knapsack(int bagCapacity, Grocery groceries[], int n)
{
    int dp[n + 1][bagCapacity + 1];

    for (int i = 0; i <= n; i++)
    {
        for (int w = 0; w <= bagCapacity; w++)
        {
            if (i == 0 || w == 0)
            {
                dp[i][w] = 0;
            }
              else if (groceries[i - 1].weight > w)
            {
                dp[i][w] = dp[i - 1][w];
            }
              else
            {
                dp[i][w] = max(dp[i - 1][w], dp[i - 1][w - groceries[i - 1].weight] + groceries[i - 1].cost);
            }
        }
    }

    return dp[n][bagCapacity];
}

int main()
{
    Grocery groceries[] =
    {
        {3, 470},
        {2, 230},
        {3, 360},
        {5, 500}
    };

    int n = sizeof(groceries) / sizeof(groceries[0]);
    int bagCapacity = 10;
    int maxCost = knapsack(bagCapacity, groceries, n);

    cout << "Maximum cost of groceries that fit in the bag: " << maxCost << "tk" << endl;

    return 0;
}
