#include <iostream>
using namespace std;

struct GroceryItem
{
    double weight;
    double value;
    char name[50];
};

void fractionalKnapsack(GroceryItem items[], int numItems, double capacity)
{
    double totalValue = 0.0;

    for (int i = 0; i < numItems; i++)
    {
        if (capacity >= items[i].weight)
        {
            totalValue = totalValue + items[i].value;
            capacity = capacity - items[i].weight;
            cout << "Bought " << items[i].weight << " kg of " << items[i].name << " for " << items[i].value << " tk" << endl;
        }
           else
        {
            double fraction = capacity / items[i].weight;
            totalValue = totalValue + (fraction * items[i].value);
            cout << "Bought " << (fraction * items[i].weight) << " kg of " << items[i].name << " for " << (fraction * items[i].value) << " tk" << endl;
            break;
        }
    }

    cout << "Total cost (fractional knapsack): " << totalValue << " tk" << endl;
}

void zeroOneKnapsack(GroceryItem items[], int numItems, double capacity)
{
    double dp[100][100] = {0};

    for (int i = 0; i < numItems; i++)
    {
        for (int w = 0; w <= capacity; w++)
        {
            if (items[i].weight <= w)
            {
                double withoutItem = dp[i][w];
                double withItem = (w - items[i].weight >= 0) ? dp[i][w - int(items[i].weight)] + items[i].value : 0;
                dp[i + 1][w] = (withoutItem > withItem) ? withoutItem : withItem;
            }
               else
            {
                dp[i + 1][w] = dp[i][w];
            }
        }
    }

    double totalValue = dp[numItems][int(capacity)];
    cout << "Total cost (0/1 knapsack): " << totalValue << " tk" << endl;
}

int main()
{
    GroceryItem items[] =
    {
        {3.0, 470.0, "Rice"},
        {2.0, 230.0, "Salt"},
        {3.0, 360.0, "Sugar"},
        {5.0, 500.0, "Onion"}
    };

    int numItems = sizeof(items) / sizeof(items[0]);
    double bagCapacity = 10.0;

    int choice;
    cout << "Enter 1 for fractional knapsack or 2 for 0/1 knapsack: ";
    cin >> choice;

    if (choice == 1)
    {
        fractionalKnapsack(items, numItems, bagCapacity);
    } else if (choice == 2)
    {
        zeroOneKnapsack(items, numItems, bagCapacity);
    }
      else
    {
        cout << "Invalid choice. Please enter 1 or 2." << endl;
    }

    int notes[] = {1000, 500, 200, 100, 50, 20, 10, 5, 2, 1};
    int amount;
    cout << "Enter the total amount for payment: ";
    cin >> amount;
    cout << "Minimum number of notes for payment: " << endl;
    for (int i = 0; i < 10; i++)
    {
        int count = amount / notes[i];
        if (count > 0)
        {
            cout << notes[i] << " tk notes: " << count << endl;
            amount = amount % notes[i];
        }
    }

    return 0;
}
