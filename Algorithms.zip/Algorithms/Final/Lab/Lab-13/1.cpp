#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Graph
{
    unordered_map<char, vector<char>> adj;

    void printAllPathsUtil(char, char, unordered_map<char, bool>&, vector<char>&);

public:
    void addEdge(char u, char v)
    {
        adj[u].push_back(v);
    }

    void printAllPaths(char s, char d)
    {
        unordered_map<char, bool> visited;
        vector<char> path;

        for (const auto& vertex : adj)
            visited[vertex.first] = false;

        printAllPathsUtil(s, d, visited, path);
    }
};

void Graph::printAllPathsUtil(char u, char d, unordered_map<char, bool>& visited, vector<char>& path)
{
    visited[u] = true;
    path.push_back(u);

    if (u == d)
    {
        for (const auto& vertex : path)
            cout << vertex << " ";
        cout << endl;
    }
    else
    {
        for (const auto& neighbor : adj[u])
        {
            if (!visited[neighbor])
                printAllPathsUtil(neighbor, d, visited, path);
        }
    }

    path.pop_back();
    visited[u] = false;
}

int main()
{
    Graph g;
    g.addEdge('A', 'B');
    g.addEdge('A', 'C');
    g.addEdge('B', 'D');
    g.addEdge('C', 'D');
    g.addEdge('C', 'E');
    g.addEdge('D', 'E');
    g.addEdge('E', 'F');
    g.addEdge('F', 'G');
    g.addEdge('G', 'H');

    char start = 'A', dest = 'E';
    cout << "Paths from " << start << " to " << dest << ":\n";
    g.printAllPaths(start, dest);

    return 0;
}
