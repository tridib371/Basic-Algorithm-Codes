#include <iostream>
#include <vector>
#include <unordered_map>
#include <stack>
using namespace std;

class Graph
{
    unordered_map<char, vector<char>> adj;

    void topologicalSortUtil(char, unordered_map<char, bool>&, stack<char>&);

public:
    void addEdge(char u, char v)
    {
        adj[u].push_back(v);
    }

    void topologicalSort()
    {
        unordered_map<char, bool> visited;
        stack<char> result;

        for (const auto& vertex : adj)
            visited[vertex.first] = false;

        for (const auto& vertex : adj)
        {
            if (!visited[vertex.first])
                topologicalSortUtil(vertex.first, visited, result);
        }

        cout << "Topological sorting order: ";
        while (!result.empty())
        {
            cout << result.top() << " ";
            result.pop();
        }
        cout << endl;
    }
};

void Graph::topologicalSortUtil(char u, unordered_map<char, bool>& visited, stack<char>& result)
{
    visited[u] = true;

    for (const auto& neighbor : adj[u])
    {
        if (!visited[neighbor])
            topologicalSortUtil(neighbor, visited, result);
    }

    result.push(u);
}

int main()
{
    Graph g;
    g.addEdge('A', 'B');
    g.addEdge('A', 'C');
    g.addEdge('B', 'D');
    g.addEdge('C', 'D');
    g.addEdge('C', 'E');
    g.addEdge('D', 'E');
    g.addEdge('E', 'F');
    g.addEdge('F', 'G');
    g.addEdge('G', 'H');

    g.topologicalSort();

    return 0;
}
